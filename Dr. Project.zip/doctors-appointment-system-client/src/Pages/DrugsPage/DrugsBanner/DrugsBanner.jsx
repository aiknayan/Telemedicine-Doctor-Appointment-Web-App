import React from 'react'
import './DrugsBanner.css'
export default function DrugsBanner() {
  return (
    <div className='drugBanner'>
        <h1 className='text-4xl text-center heading'>Our Medichine</h1>
    </div>
  )
}
