import { createBrowserRouter } from "react-router-dom";
import AddDoctor from "../../Dashboard/AddDoctor/AddDoctor";
import AddDurgs from "../../Dashboard/AddDurgs/AddDurgs";
import Allusers from "../../Dashboard/Allusers/Allusers";
import ManageDoctors from "../../Dashboard/Dashboard/ManageDoctors/ManageDoctors";
import ManageDrugs from "../../Dashboard/ManageDrugs/ManageDrugs";
import MyAppointment from "../../Dashboard/MyAppointment/MyAppointment";
import MyRivews from "../../Dashboard/MyRivews/MyRivews";
import Order from "../../Dashboard/Order/Order";
import Payment from "../../Dashboard/Payment/Payment";
import DashboardLayout from "../../Layout/DashboardLayout";
import Main from "../../Layout/Main";
import Appointment from "../../Pages/Appointment/Appointment/Appointment";
import DoctorPage from "../../Pages/DoctorPage/DoctorPage/DoctorPage";
import DrugsPage from "../../Pages/DrugsPage/DrugsPage/DrugsPage";
import Home from "../../Pages/Home/Home/Home";
import Login from "../../Pages/Login/Login";
import DisplayError from "../../Pages/Shared/DisplayError/DisplayError";
import Signup from "../../Pages/Signup/Signup";
import AdminRoute from "../AdminRoute/AdminRoute";
import PrivateRoute from "../PrivateRoute/PrivateRoute";

export const router = createBrowserRouter([
    {
        path: '/',
        element: <Main/>,
        errorElement: <DisplayError />,
        children: [
            {
                path: '/',
                element: <Home />
            },
            {
                path: '/home',
                element: <Home />
            },
            {
                path: '/appointment',
                element: <Appointment />
            },
            {
                path: '/doctor',
                element: <DoctorPage />
            },
            {
                path: '/drugs',
                element: <DrugsPage />
            },
            {
                path: '/login',
                element: <Login />
            },
            {
                path: '/signup',
                element: <Signup />
            },
        ]
    },
    {
        path: '/dashboard',
        element: <PrivateRoute> <DashboardLayout></DashboardLayout></PrivateRoute>,
        errorElement: <DisplayError />,
        children: [
            {
                path: "/dashboard",
                element: <MyAppointment />
            },
            {
                path: "/dashboard/myreviews",
                element: <MyRivews />
            },
            {
                path: "/dashboard/order",
                element: <Order/>
            },
            {
                path: "/dashboard/users",
                element: <AdminRoute> <Allusers /></AdminRoute>
            },
            {
                path: "/dashboard/adddoctor",
                element: <AdminRoute><AddDoctor /></AdminRoute>
            },
            {
                path: "/dashboard/managedoctors",
                element: <AdminRoute> <ManageDoctors /> </AdminRoute>
            },
            {
                path: "/dashboard/adddurgs",
                element: <AdminRoute> <AddDurgs /> </AdminRoute>
            },
            {
                path: "/dashboard/managedrugs",
                element: <AdminRoute> <ManageDrugs /> </AdminRoute>
            },
            {
                path: "/dashboard/payment/:id",
                element: <Payment />,
                loader: ({params}) => fetch(`http://localhost:5000/bookings/${params.id}`)
            }
            
        ]
    }
])