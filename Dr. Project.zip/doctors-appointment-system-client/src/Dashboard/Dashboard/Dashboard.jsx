import React from 'react'

export default function Dashboard({children}) {
  return (
    <div>
        <h1>Dashboard page coming soon</h1>
    </div>
  )
}
