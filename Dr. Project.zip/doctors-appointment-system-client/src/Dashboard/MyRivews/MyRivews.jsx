import React from 'react'

export default function MyRivews() {
  return (
    <div>MyRivews</div>
  )
}
