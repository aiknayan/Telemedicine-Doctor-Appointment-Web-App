export default function Order() {
    return(
        <div>
            <h2>Orders</h2>
        </div>
    )
}